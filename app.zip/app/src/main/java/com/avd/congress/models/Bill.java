package com.avd.congress.models;

import org.json.JSONObject;

/**
 * Created by avdmy on 11/15/2016.
 */

public class Bill {
    public JSONObject parsedJSON;
}
