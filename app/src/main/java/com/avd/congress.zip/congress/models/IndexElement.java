package com.avd.congress.models;

/**
 * Created by avdmy on 11/23/2016.
 */

public class IndexElement {
    public char vlaue;
    public int index;
}
